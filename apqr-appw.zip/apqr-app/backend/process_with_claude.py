import uuid
import os
import fitz  # PyMuPDF for PDF handling
import pytesseract
from pdf2image import convert_from_path
from PyPDF2 import PdfReader
from docx import Document
import pandas as pd
import logging
from openpyxl import Workbook
import requests
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import anthropic  # Claude API
import sys
if sys.platform == "win32":
    import win32com.client  # For .doc support on Windows


# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Claude API Configuration
CLAUDE_API_URL = "https://api.anthropic.com/v1/messages"
CLAUDE_API_KEY = "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"  # Replace with your actual API key
client = anthropic.Anthropic(api_key=CLAUDE_API_KEY)


# Poppler & Tesseract Paths
POPPLER_PATH = r"C:\Program Files\poppler\Library\bin"
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\tesseract-ocr\tesseract.exe"


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploads"
REPORT_DIR = "reports"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(REPORT_DIR, exist_ok=True)
app.mount("/reports", StaticFiles(directory=REPORT_DIR), name="reports")

@app.post("/upload-files/")
async def upload_files(report: UploadFile = None, checklist: UploadFile = None):
    try:
        if report:
            #Removing the file if it already exists
            if(os.path.exists(os.path.join(UPLOAD_DIR, f"report_{report.filename}"))):
                os.remove(os.path.join(UPLOAD_DIR, f"report_{report.filename}"))

            report_path = os.path.join(UPLOAD_DIR, f"report_{report.filename}")
            with open(report_path, "wb") as report_file:
                while chunk := await report.read(1024 * 1024):
                    report_file.write(chunk)

        if checklist:
            #Removing the file if it already exists
            if(os.path.exists(os.path.join(UPLOAD_DIR, f"checklist_{checklist.filename}"))):
                os.remove(os.path.join(UPLOAD_DIR, f"checklist_{checklist.filename}"))

            checklist_path = os.path.join(UPLOAD_DIR, f"checklist_{checklist.filename}")
            with open(checklist_path, "wb") as checklist_file:
                while chunk := await checklist.read(1024 * 1024):
                    checklist_file.write(chunk)

        return JSONResponse(content={"message": "Files uploaded successfully."}, status_code=200)
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

@app.post("/process-files/")
async def process_files():
    try:
        report_files = [f for f in os.listdir(UPLOAD_DIR) if f.startswith(("report_"))]
        checklist_files = [f for f in os.listdir(UPLOAD_DIR) if f.startswith(("checklist_"))]
        
        if not report_files or not checklist_files:
            return JSONResponse(content={"message": "No uploaded files found."}, status_code=400)

        report_path = os.path.join(UPLOAD_DIR, report_files[-1])
        print(f"report_path", report_path)
        checklist_path = os.path.join(UPLOAD_DIR, checklist_files[-1])
        print(f"checklist_path", checklist_path)
        
        # checklist = load_checklist(checklist_path)
        # apqr_text = extract_text_from_file(report_path)
        results = evaluate_apqr_with_claude(checklist_path, report_path)
        # results = validate_document(report_path, checklist_path, report_files[-1])

        if results:
            report_url = save_results_to_excel(results, report_files[-1])

            # Delete files after processing
            # try:
            #     os.remove(report_path)
            #     os.remove(checklist_path)
            #     print(f"Deleted processed files: {report_path}, {checklist_path}")
            # except Exception as e:
            #     logging.error(f"Error deleting files: {e}")

            return JSONResponse(content={"message": "Report generated.", "report_url": report_url}, status_code=200)
        
        return JSONResponse(content={"message": "No results to save."}, status_code=200)
    except Exception as e:
        print(f"Error processing files: {e}")
        return JSONResponse(content={"error": str(e)}, status_code=500)

@app.get("/reports/{filename}")
async def get_report(filename: str):
    file_path = os.path.join(REPORT_DIR, filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        headers={"Content-Disposition": f"attachment; filename={filename}"})

# Load checklist questions from DOCX
def load_checklist(file_path):
    doc = Document(file_path)
    return [para.text.strip() for para in doc.paragraphs if para.text.strip()]

# Extract text from different file formats
def extract_text_from_file(file_path):
    if file_path.endswith(".pdf"):
        return extract_pdf_text(file_path)
    elif file_path.endswith((".docx", ".doc")):
        return extract_docx_text(file_path)
    return ""

def extract_pdf_text(file_path):
    text = ""
    pdf = PdfReader(file_path)
    for page in pdf.pages:
        text += page.extract_text() + "\n" if page.extract_text() else ""
    return text if text.strip() else extract_text_using_ocr(file_path)

def extract_text_using_ocr(pdf_path):
    images = convert_from_path(pdf_path, poppler_path=POPPLER_PATH)
    return "\n".join(pytesseract.image_to_string(image) for image in images)

def extract_docx_text(file_path):
    doc = Document(file_path)
    return "\n".join(para.text.strip() for para in doc.paragraphs if para.text.strip())

def query_claude(question, context):
    """Queries Claude API for validation."""
    try:
        response = client.messages.create(
            model="claude-3-5-haiku-20241022",
            max_tokens=200,
            system="You are an AI expert in document validation.",
            messages=[
                {"role": "user", "content": f"Question: {question}\nContext: {context[:5000]}\nAnswer:"}
            ]
        )
        if response and response.content:
            return response.content[0].text.strip()
        return "No relevant answer found."
    except Exception as e:
        return f"Error retrieving answer: {e}"
    
# Evaluate APQR using Claude API
# def evaluate_apqr_with_claude(checklist, document_text):
    """Evaluates APQR against checklist using Claude API."""
    results = []

    for idx, question in enumerate(checklist):
        try:
            print(f"Processing question {idx + 1}/{len(checklist)}: {question[:50]}...")
            answer = query_claude(question, document_text[:100000])

            # Determine pass/fail
            result = "Pass" if answer and answer not in ["Error retrieving answer", "No relevant answer found."] else "Fail"
            results.append({"Question": question, "Answer": answer, "Result": result})

        except Exception as e:
            results.append({"Question": question, "Answer": "Error", "Result": "Fail", "Reason": str(e)})

    return results

def evaluate_apqr_with_claude(checklist_file, input_file):
    """Validate a document using Claude AI for Pharma Manufacturing reports."""
    results = []

    try:
        logging.info("Starting document validation...")

        if not os.path.exists(input_file) or not os.path.exists(checklist_file):
            logging.error("Input files are missing.")
            return []

        # Extract text from document (PDF, DOC, DOCX)
        logging.info(f"Extracting text from {input_file}...")
        document_text = extract_text_from_document(input_file)

        # Extract questions from the checklist
        logging.info(f"Extracting questions from {checklist_file}...")
        questions = extract_text_from_docx(checklist_file).split("\n")

        # Process each question
        for idx, question in enumerate(questions):
            if question.strip():
                logging.info(f"Processing question {idx + 1}/{len(questions)}: {question[:50]}...")
                
                try:
                    # Query Claude AI
                    answer = query_claude(question, document_text[:100000])
                    logging.info(f"Claude Response: {answer}")

                    # Determine validation result
                    result = "Pass" if answer and answer not in ["Error retrieving answer", "No relevant answer found."] else "Fail"

                    # Append to results
                    results.append({"Question": question, "Answer": answer, "Result": result})

                except Exception as e:
                    logging.error(f"Error processing question {idx + 1}: {e}", exc_info=True)
                    results.append({"Question": question, "Answer": "Error", "Result": "Fail", "Reason": str(e)})

        logging.info("Validation completed successfully.")

    except Exception as e:
        logging.error(f"An error occurred: {e}", exc_info=True)

    return results











def extract_text_from_scanned_pdf(pdf_path):
    """Extract text from a scanned PDF using OCR."""
    extracted_text = []
    try:
        images = convert_from_path(pdf_path, poppler_path=POPPLER_PATH)
        logging.info(f"Converted {len(images)} pages to images for OCR.")

        for i, image in enumerate(images):
            logging.info(f"OCR processing page {i + 1}...")
            gray_image = image.convert("L")  
            text = pytesseract.image_to_string(gray_image)
            extracted_text.append(text)

        return "\n\n".join(extracted_text)

    except Exception as e:
        logging.error(f"Error processing scanned PDF: {e}")
        return ""

def extract_text_from_pdf(pdf_path):
    """Extract text from a PDF, handling both digital and scanned PDFs."""
    text = ""

    if not os.path.exists(pdf_path):
        logging.error(f"PDF file '{pdf_path}' not found.")
        return text

    try:
        with fitz.open(pdf_path) as doc:
            for page in doc:
                page_text = page.get_text()
                if page_text.strip():
                    text += page_text
        
        if not text.strip():
            logging.info("No text found in PDF, applying OCR...")
            text = extract_text_from_scanned_pdf(pdf_path)

        logging.info(f"Extracted {len(text)} characters from PDF.")
    
    except Exception as e:
        logging.error(f"Error reading PDF: {e}")

    return text

def extract_text_from_docx(docx_path):
    """Extract text from DOCX files."""
    text = []
    if not os.path.exists(docx_path):
        logging.error(f"File '{docx_path}' not found.")
        return ""

    try:
        doc = Document(docx_path)
        for paragraph in doc.paragraphs:
            text.append(paragraph.text.strip())

        logging.info(f"Extracted {len(text)} paragraphs from DOCX.")
    
    except Exception as e:
        logging.error(f"Error reading DOCX: {e}")

    return "\n\n".join(text)

def extract_text_from_doc(doc_path):
    """Extract text from DOC files using Windows COM interface (only for Windows)."""
    text = []
    if not os.path.exists(doc_path):
        logging.error(f"File '{doc_path}' not found.")
        return ""

    try:
        word = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        doc = word.Documents.Open(os.path.abspath(doc_path))

        for paragraph in doc.Paragraphs:
            text.append(paragraph.Range.Text.strip())

        doc.Close()
        word.Quit()
        logging.info(f"Extracted {len(text)} paragraphs from DOC.")

    except Exception as e:
        logging.error(f"Error reading DOC file: {e}")
        return ""

    return "\n\n".join(text)

def extract_text_from_document(file_path):
    """Extract text from PDF, DOC, DOCX, and DOCS files."""
    ext = file_path.lower().split('.')[-1]

    if ext == "pdf":
        return extract_text_from_pdf(file_path)
    elif ext == "docx":
        return extract_text_from_docx(file_path)
    elif ext == "doc":
        return extract_text_from_doc(file_path)
    else:
        logging.error(f"Unsupported file type: {ext}")
        return ""

def query_claude(question, context):
    """Query Claude AI for the best answer."""
    try:
        response = client.messages.create(
            model="claude-3-5-haiku-20241022",
            max_tokens=200,
            system="You are an AI expert in document validation.",
            messages=[
                {"role": "user", "content": f"Question: {question}\nContext: {context[:5000]}\nAnswer:"}
            ]
        )

        if response and response.content:
            return response.content[0].text.strip()
        return "No relevant answer found."
    
    except Exception as e:
        logging.error(f"Error querying Claude: {e}")
        return "Error retrieving answer"

def validate_document(input_file, checklist_file, output_excel):
    """Validate a document using Claude AI for Pharma Manufacturing reports."""
    try:
        logging.info("Starting document validation...")

        if not os.path.exists(input_file) or not os.path.exists(checklist_file):
            logging.error("Input files are missing.")
            return

        # Extract text from document (PDF, DOC, DOCX)
        logging.info(f"Extracting text from {input_file}...")
        document_text = extract_text_from_document(input_file)

        # Extract questions from the checklist
        logging.info(f"Extracting questions from {checklist_file}...")
        questions = extract_text_from_docx(checklist_file)

        # Create an Excel Workbook
        logging.info("Creating Excel workbook...")
        wb = Workbook()
        ws = wb.active
        ws.title = "Validation Results"
        ws.append(["Question", "Answer", "Validation Result"])

        # Process each question
        for i, question in enumerate(questions.split("\n")):
            if question.strip():
                logging.info(f"Processing question {i+1}/{len(questions.splitlines())}: {question}")

                # Query Claude AI
                answer = query_claude(question, document_text[:100000])  
                logging.info(f"Claude Response: {answer}")

                # Determine validation result
                result = "Pass" if answer and answer not in ["Error retrieving answer", "No relevant answer found."] else "Fail"

                # Save to Excel
                ws.append([question, answer, result])

        # Save results
        logging.info(f"Saving results to {output_excel}...")
        wb.save(output_excel)
        logging.info("Validation completed successfully.")

    except Exception as e:
        logging.error(f"An error occurred: {e}", exc_info=True)



# Save evaluation results to Excel
def save_results_to_excel(results, pdf_filename):
    unique_id = uuid.uuid4().hex
    report_filename = os.path.splitext(pdf_filename)[0] + f"_{unique_id}_report.xlsx"
    report_path = os.path.join(REPORT_DIR, report_filename)
    pd.DataFrame(results).to_excel(report_path, index=False)
    return f"http://localhost:8000/reports/{report_filename}"
