import React, { useState } from "react";
import UploadBox from "./UploadBox1";
import axios from "axios";

const FileUpload = () => {
  const [files, setFiles] = useState({ REPORT: null, CHECKLIST: null });
  const [isUploading, setIsUploading] = useState(false);
  const [isUploaded, setIsUploaded] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isGenerated, setIsGenerated] = useState(false);
  const [generatedFilePath, setGeneratedFilePath] = useState("");
  const [reportData, setReportData] = useState([]);

  const handleFileSelect = (label, file) => {
    setFiles((prev) => ({ ...prev, [label]: file }));
  };

  const handleFileDelete = async (label, fileName) => {
    console.log(`Deleted ${label} and ${fileName}`);
    setFiles((prev) => ({ ...prev, [label]: null }));
    try {
        const response = await axios.delete(`http://localhost:8000/delete-file/${fileName}`);
        
        if (response.status === 200) {
          alert(`File '${fileName}' deleted successfully.`);
          // Update UI state
        //   refreshFilesList();
        } else {
          alert("Error deleting file.");
        }
      } catch (error) {
        console.error("Error deleting file:", error);
        alert("Failed to delete file.");
      }
  };

  const handleUpload = async () => {
    if (!files.REPORT || !files.CHECKLIST) {
      alert("Please select both files before uploading!");
      return;
    }

    setIsUploading(true);
    const formData = new FormData();
    formData.append("report", files.REPORT);
    formData.append("checklist", files.CHECKLIST);

    try {
      const response = await axios.post("http://localhost:8000/upload-files/", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      if (response.status === 200) {
        setIsUploaded(true);
        alert("Files uploaded successfully!");
      } else {
        alert("File upload failed!");
      }
    } catch (error) {
      console.error("Upload error:", error);
      alert("Error uploading files!");
    } finally {
      setIsUploading(false);
    }
  };

  const handleGenerateReport = async () => {
    setIsGenerating(true);

    try {
      const response = await axios.post("http://localhost:8000/process-files/", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      if (response.status === 200) {
        setIsGenerated(true);
        setGeneratedFilePath(response.data.report_url);
        fetchReportData(response.data.report_url);
        alert(`Report Generated! Download from: ${response.data.report_url}`);
      } else {
        alert("Error generating the report.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to generate the report.");
    } finally {
      setIsGenerating(false);
    }
  };

  const fetchReportData = async (reportUrl) => {
    try {
      const response = await fetch(reportUrl);
      const blob = await response.blob();
      const arrayBuffer = await blob.arrayBuffer();

      const XLSX = await import("xlsx");
      const workbook = XLSX.read(new Uint8Array(arrayBuffer), { type: "array" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(sheet);

      setReportData(jsonData);
    } catch (error) {
      console.error("Error fetching report data:", error);
    }
  };

  return (
    <div className="flex flex-col gap-6 p-10">
      <div className="flex gap-6">
        <UploadBox
          accept={{ "application/pdf": [".pdf"], "application/msword": [".doc"], "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"] }}
          label="REPORT"
          onFileSelect={handleFileSelect}
          onFileDelete={handleFileDelete}
        />
        <UploadBox
          accept={{ "application/msword": [".doc"], "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"] }}
          label="CHECKLIST"
          onFileSelect={handleFileSelect}
          onFileDelete=
          {handleFileDelete}
        />
      </div>

      <button
        onClick={handleUpload}
        disabled={isUploading || !files.REPORT || !files.CHECKLIST}
        className={`mt-4 px-6 py-2 rounded-lg text-white transition-all duration-300 ${
          isUploading ? "bg-blue-500 cursor-wait" : files.REPORT && files.CHECKLIST ? "bg-green-500 hover:bg-green-600" : "bg-gray-400 cursor-not-allowed"
        }`}
      >
        {isUploading ? "Uploading..." : "Upload Files"}
      </button>

      {isUploaded && (
        <button
          onClick={handleGenerateReport}
          disabled={isGenerating}
          className={`mt-4 px-6 py-2 rounded-lg text-white transition-all duration-300 ${isGenerating ? "bg-blue-500 cursor-wait" : "bg-purple-500 hover:bg-purple-600"}`}
        >
          {isGenerating ? "Generating Report..." : "Generate Report"}
        </button>
      )}

      {isGenerating && (
        <div className="flex flex-col items-center mt-4">
          <p className="text-lg font-semibold text-gray-700 mb-2">Analyzing report...</p>
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}

      {isGenerated && reportData.length > 0 && (
        <div className="mt-6">
          <h3 className="text-xl font-semibold mb-4">Generated Report</h3>
          <div className="overflow-auto max-h-96 border rounded-lg">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead className="bg-gray-200">
                <tr>
                  {Object.keys(reportData[0]).map((key, index) => (
                    <th key={index} className="border border-gray-300 px-4 py-2">{key}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {reportData.map((row, rowIndex) => (
                  <tr key={rowIndex} className="hover:bg-gray-100">
                    {Object.values(row).map((value, colIndex) => (
                      <td key={colIndex} className="border border-gray-300 px-4 py-2">{value}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
