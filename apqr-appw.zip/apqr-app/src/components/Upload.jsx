import React, { useState } from "react";
import UploadBox from "./UploadBox";
import axios from "axios";

const FileUpload = () => {
  const [filesUploaded, setFilesUploaded] = useState({
    REPORT: null,
    CHECKLIST: null,
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [isGenerated, setIsGenerated] = useState(false);
  const [generatedFilePath, setGeneratedFilePath] = useState("");
  const [reportData, setReportData] = useState([]); // Stores report data
  const [fileName, setFileName] = useState('')

  const handleFileUpload = (label, file) => {
    console.log(`Uploaded ${label}:`, file);
    setFileName(file);
    setFilesUploaded((prev) => ({ ...prev, [label]: file }));
  };

  const handleGenerateReport = async () => {
    if (!filesUploaded.REPORT || !filesUploaded.CHECKLIST) {
      alert("Please upload both files before generating the report.");
      return;
    }

    setIsGenerating(true);
    const formData = new FormData();
    formData.append("report", filesUploaded.REPORT);
    formData.append("checklist", filesUploaded.CHECKLIST);

    try {
      const response = await axios.post("http://localhost:8000/process-files/", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      console.log("Process files:", response);
      if (response.status === 200) {
        setIsGenerated(true);
        setGeneratedFilePath(response.data.report_url);

        // Fetch the generated Excel file and parse it as JSON
        fetchReportData(response.data.report_url);
        alert(`Report Generated! Download from: ${response.data.report_url}`);
      } else {
        alert("Error generating the report.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to generate the report.");
    }
    finally {
      setIsGenerating(false);
    }
  };

  // Function to fetch report data and parse it
  const fetchReportData = async (reportUrl) => {
    try {
      console.log("Fetching report data from:", reportUrl);
      const response = await fetch(reportUrl);
  
      console.log("Response headers:", response.headers);
      // Ensure response is OK and the correct content type
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
  
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("spreadsheetml")) {
        console.error("Received content type:", contentType);
        throw new Error("Invalid file format. Expected an Excel file.");
      }
  
      // Read the response as a Blob and convert to ArrayBuffer
      const blob = await response.blob();
      const arrayBuffer = await blob.arrayBuffer();
  
      const XLSX = await import("xlsx"); // Dynamically import xlsx
      const workbook = XLSX.read(new Uint8Array(arrayBuffer), { type: "array" });
  
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(sheet);
      
      setReportData(jsonData); // Update the state
  
    } catch (error) {
      console.error("Error fetching report data:", error);
    }
  };
  
  
  const handleDownloadReport = () => {
    if (generatedFilePath) {
      const link = document.createElement("a");
      link.href = generatedFilePath;
      link.setAttribute("download", "Generated_Report.xlsx");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else {
      alert("No report available to download.");
    }
  };

  return (
    <div className="flex flex-col gap-6 p-10">
      <div className="flex gap-6">
        <UploadBox 
          accept={{ 
            "application/pdf": [".pdf"],
            "application/msword": [".doc"],
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
           }} 
          label="REPORT"
          onFileUpload={handleFileUpload}
        />
        <UploadBox
          accept={{
            "application/msword": [".doc"],
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
          }}
          label="CHECKLIST"
          onFileUpload={handleFileUpload}
        />
      </div>
      
      <button
        onClick={handleGenerateReport}
        disabled={isGenerating || !filesUploaded.REPORT || !filesUploaded.CHECKLIST}
        className={`mt-4 px-6 py-2 rounded-lg text-white transition-all duration-300 ${
          isGenerating
            ? "bg-blue-500 cursor-wait" // Change color while generating
            : filesUploaded.REPORT && filesUploaded.CHECKLIST
            ? "bg-green-500 hover:bg-green-600" // Normal state
            : "bg-gray-400 cursor-not-allowed" // Disabled state
        }`}
      >
        {isGenerating ? "Generating...." : "Generate Report"}
      </button>

      {/* Loading bar for generating report */}
      {isGenerating && (
        <div className="flex flex-col items-center mt-4">
          <p className="text-lg font-semibold text-gray-700 mb-2">Analysing report...</p>
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}

      {/* Display report in table format */}
      {!isGenerating && isGenerated && reportData.length > 0 && (
        <div className="mt-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold mb-4">Generated Report</h3>
            <button 
                onClick={handleDownloadReport} 
                className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
              >
                Download Report
            </button>
          </div>
          <div className="overflow-auto max-h-96 border rounded-lg">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead className="bg-gray-200">
                <tr>
                  {Object.keys(reportData[0]).map((key, index) => (
                    <th key={index} className="border border-gray-300 px-4 py-2">{key}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {reportData.map((row, rowIndex) => (
                  <tr key={rowIndex} className="hover:bg-gray-100">
                    {Object.values(row).map((value, colIndex) => (
                      <td key={colIndex} className="border border-gray-300 px-4 py-2">
                        {value}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
