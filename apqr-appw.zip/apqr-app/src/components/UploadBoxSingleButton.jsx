import React, { useState } from "react";
import { useDropzone } from "react-dropzone";
import axios from "axios";
import reports from "../assets/reports.png";

const UploadBox = ({ accept, label, onFileSelect }) => {
  const [file, setFile] = useState(null);

  const { getRootProps, getInputProps } = useDropzone({
    accept,
    multiple: false,
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        setFile(acceptedFiles[0]);
        onFileSelect(label, acceptedFiles[0]); // Notify parent component
      }
    },
  });

  return (
    <div className="flex flex-col items-center border-2 border-dashed border-gray-400 rounded-lg p-6 w-full h-60 cursor-pointer hover:border-gray-600 transition-all">
      <div {...getRootProps()} className="text-center">
        <input {...getInputProps()} />
        <img src={reports} alt="Upload" className="w-12 h-12 mx-auto mb-3" />
        <p className="font-semibold">Click or Drag {label} here</p>
        {file && <p className="text-sm text-green-600 mt-1">{file.name}</p>}
      </div>
    </div>
  );
};

const FileUpload = () => {
  const [filesUploaded, setFilesUploaded] = useState({
    REPORT: null,
    CHECKLIST: null,
  });
  const [uploading, setUploading] = useState(false);
  
  const handleFileSelect = (label, file) => {
    setFilesUploaded((prev) => ({ ...prev, [label]: file }));
  };

  const handleUpload = async () => {
    if (!filesUploaded.REPORT || !filesUploaded.CHECKLIST) {
      alert("Please upload both files before proceeding.");
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append("report", filesUploaded.REPORT);
    formData.append("checklist", filesUploaded.CHECKLIST);

    try {
      const response = await axios.post("http://localhost:8000/upload-files/", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      console.log("Upload response:", response.data);
      alert("Files uploaded successfully!");
    } catch (error) {
      console.error("Upload failed:", error);
      alert("Error uploading files!");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="flex flex-col gap-6 p-10">
      <div className="flex gap-6">
        <UploadBox
          accept={{
            "application/pdf": [".pdf"],
            "application/msword": [".doc"],
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
          }}
          label="REPORT"
          onFileSelect={handleFileSelect}
        />
        <UploadBox
          accept={{
            "application/msword": [".doc"],
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
          }}
          label="CHECKLIST"
          onFileSelect={handleFileSelect}
        />
      </div>
      <button
        onClick={handleUpload}
        disabled={uploading}
        className={`mt-4 px-6 py-2 rounded-lg text-white transition-all duration-300 ${
          uploading ? "bg-blue-500 cursor-wait" : "bg-green-500 hover:bg-green-600"
        }`}
      >
        {uploading ? "Uploading..." : "Upload Files"}
      </button>
    </div>
  );
};

export default FileUpload;
