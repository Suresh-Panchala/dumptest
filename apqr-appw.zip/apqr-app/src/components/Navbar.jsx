import React from "react";
import logo from '../assets/pharma_crux_logo.jpeg';

const Navbar = () => {
  return (
    <nav className="bg-black py-4 px-6 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        {/* Left: Logo */}
        <div className="flex items-center">
          <img src={logo} alt="Logo" className="h-8 mr-2" />
          {/* <span className="text-lg font-semibold">PharmaCrux</span> */}
        </div>

        {/* Center: Navigation Links */}
        <ul className="hidden md:flex space-x-6">
          {/* <li className="relative group">
            <button className="text-gray-700 hover:text-black">Reports ▾</button>
            
            <div className="absolute left-0 mt-2 w-40 bg-white shadow-lg rounded-md opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
              <a href="#" className="block px-4 py-2 hover:bg-gray-200">Report 1</a>
              <a href="#" className="block px-4 py-2 hover:bg-gray-200">Report 2</a>
            </div>
          </li> */}
          <li className="relative group">
            <button className="text-gray-400 hover:text-gray-200">Contact Us ▾</button>
            {/* Dropdown */}
            <div className="absolute left-0 mt-2 w-40 bg-white shadow-lg rounded-md opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
              <a href="#" className="block px-4 py-2 hover:bg-gray-200">Email</a>
              <a href="#" className="block px-4 py-2 hover:bg-gray-200">Support</a>
            </div>
          </li>
        </ul>

        {/* Right: Buttons */}
        <div className="flex items-center space-x-4">
          <button className="text-gray-300 hover:text-gray-100">Log In</button>
          <button className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-400">
            Sign Up
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
