import axios from 'axios';
import { useState } from 'react';

const UploadForm = () => {
    const [pdfFile, setPdfFile] = useState(null);
    const [checklistFile, setChecklistFile] = useState(null);
    const [isGenerating, setIsGenerating] = useState(false);
    const [genreatedFilePath, setGenratedFilePath] = useState('')

    const handleSubmit = async (e) => {
        e.preventDefault();

        setIsGenerating(true)

        const formData = new FormData();
        formData.append('pdf', pdfFile);
        formData.append('checklist', checklistFile);

        try {
            const response = await axios.post('http://localhost:8000/process-files/', formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });
            
            console.log('Report URL:', response.data.report_url);
            setGenratedFilePath(response.data.report_url)
            setIsGenerating(false)
        } catch (error) {
            setIsGenerating(false)
            console.error('Error uploading files:', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <div className='flex row justify-center'>
                <h1 className='p-4 font-bold'>Pick PDF file: </h1>
                <input className='p-4' type="file" onChange={(e) => setPdfFile(e.target.files[0])} accept="application/pdf" required />
            </div>
            <div className='flex row justify-center'>
                <h2 className='p-4 font-bold'>Pick Checklist file: </h2>
                <input className='p-4' type="file" onChange={(e) => setChecklistFile(e.target.files[0])} accept=".docx" required />
            </div>
            <div className="m-12">
                <button className='border-black rounded pl-4 pr-4 bg-gray-200 font-bold' type="submit">Generate Report</button>
            </div>
            {isGenerating ? (
                <div>
                    <h3>Genrating report...</h3>
                </div>
            ) : (
                <div>
                    <h2 className='text-green'>Generated file path is located at : {genreatedFilePath}</h2>
                </div>
            )}
        </form>
    );
};

export default UploadForm;
