import React, { useState } from "react";
import { useDropzone } from "react-dropzone";
import axios from "axios";
import report from "../assets/report.png";
import checklist from "../assets/checklist.png";
import reports from "../assets/reports.png";

const UploadBox = ({ accept, label, onFileUpload }) => {
  const [file, setFile] = useState(null);
  const [isUploaded, setIsUploaded] = useState(false);
  const [uploading, setUploading] = useState(false);

  const { getRootProps, getInputProps } = useDropzone({
    accept,
    multiple: false,
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        console.log("Accepted file:", acceptedFiles[0]);
        setFile(acceptedFiles[0]);
        setIsUploaded(false);
      }
    },
  });

  const handleUpload = async () => {
    if (!file) {
      alert("Please select a file before uploading!");
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append(label.toLowerCase(), file);

    console.log("Uploading file:", file);
    try {
      const response = await axios.post("http://localhost:8000/upload-files/", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });


      console.log("Uploading response:", response.data);

      if (response.status === 200) {
        setIsUploaded(true);
        onFileUpload(label, file.name); // Notify parent component
      } else {
        alert("File upload failed!");
      }
    } catch (error) {
      console.error("Upload failed:", error);
      alert("Error uploading file!");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="flex flex-col items-center border-2 border-dashed border-gray-400 rounded-lg p-6 w-full h-60 cursor-pointer hover:border-gray-600 transition-all">
      <div {...getRootProps()} className="text-center">
        <input {...getInputProps()} />
        <img
          src={reports}
          alt="Upload"
          className="w-12 h-12 mx-auto mb-3"
        />
        <p className="font-semibold">Click or Drag {label} here</p>
        {file && <p className="text-sm text-green-600 mt-1">{file.name}</p>}
      </div>
      <button
        onClick={handleUpload}
        disabled={uploading || isUploaded}
        className="mt-3 px-4 py-2 border rounded-lg bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50"
      >
        {uploading ? "Uploading..." : isUploaded ? "Uploaded" : "Upload"}
      </button>
    </div>
  );
};

export default UploadBox;
