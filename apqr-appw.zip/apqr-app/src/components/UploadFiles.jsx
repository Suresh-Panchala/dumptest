import React, { useState } from "react";
import { useDropzone } from "react-dropzone";
import axios from "axios";
import report from '../assets/report.png'
import checklist from '../assets/checklist.png'
// import UploadBox from "./UploadBox";

const UploadBox = ({ accept, label }) => {
    const [isUploaded, setIsUploaded] = useState(false)
    const [pdfFile, setPdfFile] = useState(null);
    const [checklistFile, setChecklistFile] = useState(null);
    const [isGenerating, setIsGenerating] = useState(false);
    const [genreatedFilePath, setGenratedFilePath] = useState('')

    const { getRootProps, getInputProps } = useDropzone({
      accept,
      multiple: true,
      maxFiles: 5,
      onDrop: (acceptedFiles) => {
        setIsUploaded(true)
        console.log(`Uploaded ${label}:`, acceptedFiles);
      },
    });

    const handleSubmit = async (e) => {
        e.preventDefault();

        setIsGenerating(true)

        const formData = new FormData();
        formData.append('pdf', pdfFile);
        formData.append('checklist', checklistFile);

        try {
            const response = await axios.post('http://localhost:8000/process-files/', formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });
            
            console.log('Report URL:', response.data.report_url);
            setGenratedFilePath(response.data.report_url)
            setIsGenerating(false)
        } catch (error) {
            setIsGenerating(false)
            console.error('Error uploading files:', error);
        }
    };

  return (
    <div
      {...getRootProps()}
      className="flex flex-col items-center justify-center border-2 border-dashed border-gray-400 rounded-lg p-6 w-full h-60 cursor-pointer hover:border-gray-600 transition-all"
    >
      <input {...getInputProps()} />
      <div className="text-center">
        
        <img
          src={label === "REPORT" ? report : checklist}
          alt="Upload"
          className="w-12 h-12 mx-auto mb-3"
        />
        <p className="font-semibold">Click to Upload or Drag {label} here</p>
        <p className="text-sm text-gray-500">{isUploaded ? `Uploaded ${label}` : ""}</p>
        <button className="mt-3 px-4 py-2 border rounded-lg hover:bg-gray-100">
          Upload
        </button>
      </div>
    </div>
  );
};

const FileUpload = () => {
  return (
    <div className="flex gap-6 p-10">
      <UploadBox 
        accept={{ "application/pdf": [".pdf"] }} 
        label="REPORT" 
      />

      <UploadBox
        accept={{
          "application/msword": [".doc"],
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            [".docx"],
        }}
        label="CHECKLIST"
      />
    </div>
  );
};

export default FileUpload;
