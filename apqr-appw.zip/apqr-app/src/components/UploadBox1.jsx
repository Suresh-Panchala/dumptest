import React, { useState } from "react";
import { useDropzone } from "react-dropzone";
import reportIcon from "../assets/report.png";
import checklistIcon from "../assets/checklist.png";
import { XCircleIcon } from "@heroicons/react/24/solid";


const UploadBox = ({ accept, label, onFileSelect, onFileDelete }) => {
  const [file, setFile] = useState(null);

  const { getRootProps, getInputProps } = useDropzone({
    accept,
    multiple: false,
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        setFile(acceptedFiles[0]);
        onFileSelect(label, acceptedFiles[0]);
      }
    },
  });

  const handleDelete = () => {
    setFile(null);
    onFileDelete(label, file.name);
  };

  return (
    <div className="flex flex-col items-center border-2 border-dashed border-gray-400 rounded-lg p-6 w-full h-60 cursor-pointer hover:border-gray-600 transition-all">
      <div {...getRootProps()} className="text-center">
        <input {...getInputProps()} />
        <img src={label === "REPORT" ? reportIcon : checklistIcon} alt="Upload" className="w-12 h-12 mx-auto mb-3" />
        <p className="font-semibold">Click or Drag {label} here</p>
        {file && <p className="text-sm text-green-600 mt-1">{file.name}</p>}
      </div>
      {file && (
        <button onClick={handleDelete} className="mt-2 flex items-center text-red-500 hover:text-red-700">
          <XCircleIcon className="w-5 h-5 mr-1" /> Delete
        </button>
      )}
    </div>
  );
};

export default UploadBox;
